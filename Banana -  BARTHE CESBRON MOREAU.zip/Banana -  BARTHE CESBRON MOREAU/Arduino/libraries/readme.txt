Pour plus d'information sur l'installation des biblioth�ques, regardez: http://www.arduino.cc/en/Guide/Libraries
